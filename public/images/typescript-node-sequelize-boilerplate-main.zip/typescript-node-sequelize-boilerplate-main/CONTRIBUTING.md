# Contributing to Typescript-Node-Sequelize-Boilerplate


#  Instructions
## Create an isuue
 - First of all, open an issue in the repository,
   describing the contribution you would like to make, the bug you found or any
   other ideas you have. 


## Fixing issues
 - Fork the project in your account and create a branch with your fix:
   `feat/your-feature` or `fix/some-issue`.

 - Commit your changes in that branch, 


## Creating a pull request

 - Open a pull request, and reference the initial issue in the pull request
   message (e.g. *fixes #<your-issue-number>*). Write a good description and
   title, so everybody will know what is fixed/improved.

 - If it makes sense, add screenshots, gifs etc., so it is easier to see what
   is going on.

## Review
Before accepting your contributions, request will be reviewed. You may get feedback
about what should be fixed in your modified code. If so, just keep committing
in your branch and the pull request will be updated automatically.

## Final
Finally, your contributions will be merged

Thanks!


